# Render Build Script for Frontend
#!/bin/bash

# Install dependencies
npm install

# Build the project
npm run build

echo "Frontend build complete"
